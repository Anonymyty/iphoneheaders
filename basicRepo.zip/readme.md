This is a somewhat ready-to-go Cydia repository 

This is intended to be used on an iOS device and using GitHub. If it's not, I'm not sure how well all this will work. 

Before you do anything, set-up your GitHub repository. If you don't have a GitHub account, you can make one for free at github.com
Make a new repository, and call it whatever you'd like

First thing you need to do is get perl. You can get it from http://coolstar.org/publicrepo/

Once that'd installed, search for perl in your file manager. Locate "perl" and "perl.5.22.0". Select them, and symbolically link them to /usr/bin 

Go to the .git folder in this setup folder and find the config file. Change the parts in square brackets to the appropriate names. For me, the full string looks like this: 
[remote "origin"]
	url = https://github.com/ipadkid358/ipadkid358.github.io.git

Your repository is now ready to go! 

Just a few more things. Head over to the Release file and open it with a text editor. There are three fields you'll want to edit. I've already put labels on them. Just remove the descriptive text, and fill it out as you'd like. Last thing . Head over to the packageMe file and open it with a text editor. Change the [this folder name] text to whatever you have named this folder. 

If you have any debs, you can drop them into the /debs folder. Head over to your Terminal and cd into this folder. Then type `./packageMe` 
This will fully set everything up and you just have to type in your Github username and password. You'll do this anytime you want to push out a package.  


If you want, you can add a CydiIcon.png 
This should be 120 by 120 and will show up in the sources page, as well as at the bottom of packages in Cydia 


Creds to Antique_Dev, fidele007, and Saurik